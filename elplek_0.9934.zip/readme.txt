  Description    

    Elplek is a short circuit and load flow program 
    Calculates all currents in a network in the case of different faults 
    The initial short circuit currents Ik"are calculated using the 
    superposition method, because it is more realistic than the 
    methods described in standards. 
    The prefault state can be taken from a load flow calculation, or 
    from a straightforward solution of the network.

  Download and Installation instructions 

    Download the compressed ("zipped") program file elplek.zip  
    Unzip the file and put the program file elplek.exe, the help file 
    elplek.hlp and the contents file elplek.cnt, the sample file
    for relay curves TestCurves.csv, and the sample file InverseEpac.equ
    for relay curve in the same directory (of your choice).
 
    Put the example files *.sld (single line diagram files) in a directory 
    of your choice. It can be the same as or different from the directory, 
    where the program file is.
    The icon file net.ico is included for an possoble shortcut 

  Requirements   
    The program has been tested in Win Me, Win 2000, Win XP, Win Vista, Win7
    and Win8.
    The program itself runs in Vista and higher, but the help file needs an additional
    file, available at http://support.microsoft.com/kb/917607/en-us
 
    When running in Win8, there should not be any magnification in the screen.

    The program has been earlier tested in Win95 and Win98, but not recently.
    (It should run also in these operating systems, because no essential
     changes have been made.)
    
    The program has been reported to run in Linux with Wine installed, but
    I have not tested it there. 


    The program can be run in a PC with 100 MHz Pentium and  
    a 800 * 600 display (or even a 640 * 480), but a faster PC and  
    especially a larger display are better