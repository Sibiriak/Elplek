Source files of the program elplek.exe

The program elplek has been written using Delphi 2. 
I have tried to compile it with a more recent version of Delphi, but
without much success. There are some details, that do not compile,
(probably) pointers to properties of visual components.

NOTE: The project file is imagopro.dpr, and the main unit is
imagopas.pas, and the main form is imagopas.dfm. When the program
is compiled, the result (the executable) is thus imagopro.exe (!)
The name must/should be changed manually to elplek (!)
(Imagopro and imagopas are the original, working names of the project)

NOTE: The program uses some (free) third part components. They are
described ... elsewhere... 

NOTE: There are certainly some unnecessary, old files included.

NOTE: The program is messy, unfortunately, and poorly documented.
Maybe some day... 